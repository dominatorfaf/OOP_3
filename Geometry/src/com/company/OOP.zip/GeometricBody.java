package com.company;

interface GeometricBody {
    float getSurface();

    float getVolume();
}
