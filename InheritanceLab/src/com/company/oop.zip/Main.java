package com.company;

public class Main {
    public static void main(String[] args) {
        J j = new J("value", new X("Madagascar"));

        j.printState();
    }
}
