package com.company;

class X {
    private String name;

    public X(String x) {
        name = x;
    }

    public String getX() {
        return name;
    }
}
